=== Woocommerce Approve Plugin ===
Contributors: Wellington Souza
Donate link: N/A
Tags: approve, kwippped,woocommerce
Requires at least: 4.6
Tested up to: 5.4
Stable tag: 1.4.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Provides the necessary structure to retrieve and use KWIPPED APPROVE lender network rates and other information.

== Description ==

APPROVE by KWIPPED provides businesses with a network of finance lenders specialized in b2b transactions.
It add the needed AJAX capabilities to wordpress to get an instant finance rate for the total in the current
woocommerce cart. Rather than providing a finished front end button, it provides web designers with the ability
to add finance rate information in any tag or place in any existing page.

== Installation ==

Download the plugin from the dist folder at  https://github.com/KWIPPED/woocommerce-approve-plugin.

1. Visit the Plugins page of your Wordpress instance and click on "Add New"
1. Click on "Uoload Plugin" and point to the recently downloaded woocommerce-approve-plugin.php file

More informatinon on how to integrate it into your Worpress site is available at https://github.com/KWIPPED/woocommerce-approve-plugin.

== Frequently Asked Questions ==

Please visit https://github.com/KWIPPED/woocommerce-approve-plugin.

== Changelog ==
= 1.4.0 =
* Stable release.

= 1.3.9 =
* Updated plugin for naming consistency.

= 1.3.8 =
* Added settings page.

= 1.3.7 =
* The first publically avaialble version.